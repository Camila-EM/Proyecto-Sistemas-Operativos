/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto2;

import java.util.Stack;

/**
 *
 * @author Usuario
 */
public class fifo extends javax.swing.JFrame {

    /**
     * Creates new form fifo
     */
    public fifo() {
        initComponents();
        
    }
    
    public  void runde()
{Integer a,b,c,d,e,f,g,h,i,j;
 String a2,b2,d2,c2,e2,f2,g2,h2,i2,j2;
        a2=a1.getText();
        b2=b1.getText();
        c2=c1.getText();
        d2=d1.getText();
        e2=e1.getText();
        f2=f1.getText();
        
        String array1[]={a2,b2,c2,d2,e2,f2};
        int fallos=6;
        //primero
        jl1.setText(array1[0]);
        
        //segundo
        if(array1[0].equals(array1[1])){
            jl4.setText(array1[0]);
            fallos --;}
        else {
            jl4.setText(array1[0]);
            jl5.setText(array1[1]);
        };
        
        //tercero
        if(array1[0].equals(array1[2])){
            fallos --;
            jl7.setText(array1[0]);
            jl8.setText(jl5.getText());
        }
        else {
            jl7.setText(array1[0]);
            if (array1[1].equals(array1[2])){
                fallos --;
                jl8.setText(array1[1]);
                
        }
            else {
                if(jl5.getText().equals("--")){
                    jl8.setText(array1[2]);
                }
                else {jl9.setText(array1[2]);
                      jl8.setText(array1[1]);
                };
                      
            };
        };
        
          //cuarto
        switch (fallos){
            case 6: 
                if(jl7.getText().equals(array1[3])){
                    fallos--;
                    jl10.setText(array1[3]);
                    jl11.setText(jl8.getText());
                    jl12.setText(jl9.getText());
                }
                else{
                    if(jl8.getText().equals(array1[3])){   
                       fallos--;
                       jl10.setText(jl7.getText());
                       jl12.setText(jl9.getText());
                       jl11.setText(array1[3]);
                }
                    else{
                        if(jl9.getText().equals(array1[3])){   
                        fallos--;
                        jl10.setText(jl7.getText());
                        jl11.setText(jl8.getText());
                        jl12.setText(array1[3]);
                }
                        else {jl10.setText(array1[3]);
                             jl11.setText(jl8.getText());
                             jl12.setText(jl9.getText());
                        };
                               };
                };
                
                break;
                
            case 5:
                if (jl7.getText().equals(array1[3])){
                    fallos--;
                    jl10.setText(array1[3]);
                    jl11.setText(jl8.getText());
                    jl12.setText(jl9.getText());
                }
                else {
                    if (jl8.getText().equals(array1[3])){
                    fallos--;
                    jl10.setText(jl7.getText());
                    jl11.setText(array1[3]);
                    jl12.setText(jl9.getText());
                    }
                    else {
                    jl10.setText(jl7.getText());
                    jl11.setText(jl8.getText());
                    jl12.setText(array1[3]);
                    };
                };
                
                break;
                
            case 4:
                if (jl7.getText().equals(array1[3])){
                    fallos--;
                    jl10.setText(array1[3]);
                    jl11.setText(jl8.getText());
                    jl12.setText(jl9.getText());
                }
                else {
                    jl10.setText(jl7.getText());
                    jl11.setText(array1[3]);
                    jl12.setText(jl9.getText());
                    }; 
                break;   
        }
        
        //quinto
    //   int fallos2=0;
    //   fallos2=fallos;

        switch (fallos){
            case 5: 
                if(jl10.getText().equals(array1[4])){
                    fallos--;
                    jl13.setText(array1[4]);
                    jl14.setText(jl11.getText());
                    jl15.setText(jl12.getText());
                }
                else{
                    if(jl11.getText().equals(array1[4])){   
                       fallos--;
                       jl13.setText(jl10.getText());
                       jl14.setText(array1[4]);
                       jl15.setText(jl12.getText());
                }
                    else{
                        if(jl2.getText().equals(array1[4])){   
                        fallos--;
                        jl13.setText(jl10.getText());
                        jl14.setText(jl11.getText());
                        jl15.setText(array1[4]);
                }
                        else {jl13.setText(array1[4]);
                             jl14.setText(jl11.getText());
                             jl15.setText(jl12.getText());
                        };
                               };
                };
                
                break;
                
            case 4:
                if (jl10.getText().equals(array1[4])){
                    fallos--;
                    jl13.setText(array1[4]);
                    jl14.setText(jl11.getText());
                    jl15.setText(jl12.getText());
                }
                else {
                    if (jl11.getText().equals(array1[4])){
                    fallos--;
                    jl13.setText(jl10.getText());
                    jl14.setText(array1[4]);
                    jl15.setText(jl12.getText());
                    }
                    else {
                    jl13.setText(jl10.getText());
                    jl14.setText(jl11.getText());
                    jl15.setText(array1[4]);
                    };
                };
                
                break;
                
            case 3: 
                if (jl10.getText().equals(array1[4])){
                    fallos--;
                    jl13.setText(array1[4]);
                    jl14.setText(jl11.getText());
                    jl15.setText(jl12.getText());
                }
                else {
                    jl13.setText(jl10.getText());
                    jl14.setText(array1[4]);
                    jl15.setText(jl12.getText());
                    }; 
                break; 
                
            default: 
                if(jl10.getText().equals(array1[4])){
                    fallos--;
                    jl13.setText(array1[4]);
                    jl14.setText(jl1.getText());
                    jl15.setText(jl2.getText());
                }
                else{
                    if(jl11.getText().equals(array1[4])){   
                       fallos--;
                       jl13.setText(jl10.getText());
                       jl14.setText(array1[4]);
                       jl15.setText(jl12.getText());
                }
                    else{
                        if(jl2.getText().equals(array1[4])){   
                        fallos--;
                        jl13.setText(jl10.getText());
                        jl14.setText(jl11.getText());
                        jl15.setText(array1[4]);
                }
                        else {jl13.setText(jl10.getText());
                             jl14.setText(array1[4]);
                             jl15.setText(jl12.getText());
                        };
                               };
                };
        }
       
        //seis
         switch (fallos){
             case 6: 
                if(jl13.getText().equals(array1[5])){
                    fallos--;
                    jl16.setText(array1[5]);
                    jl17.setText(jl14.getText());
                    jl18.setText(jl15.getText());
                    
                }
                else{
                    if(jl14.getText().equals(array1[5])){   
                       fallos--;
                       jl16.setText(jl13.getText());
                       jl17.setText(array1[5]);
                       jl18.setText(jl15.getText());
                }
                    else{
                        if(jl15.getText().equals(array1[5])){   
                        fallos--;
                        jl15.setText(jl13.getText());
                        jl17.setText(jl14.getText());
                        jl18.setText(array1[5]);
                }
                        else {jl16.setText(jl13.getText());
                             jl17.setText(jl14.getText());
                             jl18.setText(array1[5]);
                        };
                               };
                };
            case 5: 
                if(jl13.getText().equals(array1[5])){
                    fallos--;
                    jl16.setText(array1[5]);
                    jl17.setText(jl14.getText());
                    jl18.setText(jl15.getText());
                    
                }
                else{
                    if(jl14.getText().equals(array1[5])){   
                       fallos--;
                       jl16.setText(jl13.getText());
                       jl17.setText(array1[5]);
                       jl18.setText(jl15.getText());
                }
                    else{
                        if(jl15.getText().equals(array1[5])){   
                        fallos--;
                        jl15.setText(jl13.getText());
                        jl17.setText(jl14.getText());
                        jl18.setText(array1[5]);
                }
                        else {jl16.setText(jl13.getText());
                             jl17.setText(array1[5]);
                             jl18.setText(jl15.getText());
                        };
                               };
                };
                
                break;
                
            case 4:
                 if(jl13.getText().equals(array1[5])){
                    fallos--;
                    jl16.setText(array1[5]);
                    jl17.setText(jl14.getText());
                    jl18.setText(jl15.getText());
                    
                }
                else{
                    if(jl14.getText().equals(array1[5])){   
                       fallos--;
                       jl16.setText(jl13.getText());
                       jl17.setText(array1[5]);
                       jl18.setText(jl15.getText());
                }
                    else{
                        if(jl15.getText().equals(array1[5])){   
                        fallos--;
                        jl15.setText(jl13.getText());
                        jl17.setText(jl14.getText());
                        jl18.setText(array1[5]);
                }
                        else {jl16.setText(array1[5]);
                             jl17.setText(jl14.getText());
                             jl18.setText(jl15.getText());
                        };
                               };
                };
                
                break;
                
            case 3:
                if (jl13.getText().equals(array1[5])){
                    fallos--;
                    jl16.setText(array1[4]);
                    jl17.setText(jl14.getText());
                    jl18.setText(jl15.getText());
                }
                else {
                      if(jl14.getText().equals(array1[5])){   
                       fallos--;
                       jl16.setText(jl13.getText());
                       jl17.setText(array1[5]);
                       jl18.setText(jl15.getText());
                      }else {
                        jl16.setText(jl13.getText());
                        jl17.setText(jl14.getText());
                        jl18.setText(array1[5]);
                      } 
                }; 
                break; 
                
            case 2: 
                if(jl13.getText().equals(array1[5])){
                    fallos--;
                    jl16.setText(array1[5]);
                    jl17.setText(jl14.getText());
                    jl18.setText(jl15.getText());
                }
                else{
                       jl16.setText(jl13.getText());
                       jl17.setText(array1[5]);
                       jl18.setText(jl15.getText());
                       
                    }}

                //fin//
        falloscont.setText(fallos+"");
}
    
    
  

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        falloscont = new javax.swing.JLabel();
        c1 = new javax.swing.JTextField();
        d1 = new javax.swing.JTextField();
        e1 = new javax.swing.JTextField();
        f1 = new javax.swing.JTextField();
        a1 = new javax.swing.JTextField();
        b1 = new javax.swing.JTextField();
        jl1 = new javax.swing.JLabel();
        jl2 = new javax.swing.JLabel();
        jl3 = new javax.swing.JLabel();
        jl4 = new javax.swing.JLabel();
        jl17 = new javax.swing.JLabel();
        jl5 = new javax.swing.JLabel();
        jl18 = new javax.swing.JLabel();
        jl6 = new javax.swing.JLabel();
        jl7 = new javax.swing.JLabel();
        jl8 = new javax.swing.JLabel();
        jl13 = new javax.swing.JLabel();
        jl14 = new javax.swing.JLabel();
        jl15 = new javax.swing.JLabel();
        jl16 = new javax.swing.JLabel();
        jl9 = new javax.swing.JLabel();
        jl10 = new javax.swing.JLabel();
        jl11 = new javax.swing.JLabel();
        jl12 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        LIMPIAR = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 204, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        falloscont.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        falloscont.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        falloscont.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(falloscont, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 170, 60, 40));

        c1.setText(" ");
        c1.setMaximumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(c1, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 20, 67, -1));

        d1.setText(" ");
        d1.setMaximumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(d1, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 20, 67, -1));

        e1.setText(" ");
        e1.setMaximumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(e1, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 20, 68, -1));

        f1.setText(" ");
        f1.setMaximumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(f1, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 20, 78, -1));

        a1.setText(" ");
        a1.setMaximumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(a1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 62, -1));

        b1.setText(" ");
        b1.setMaximumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(b1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 20, 67, -1));

        jl1.setText("--");
        jl1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl1.setMaximumSize(new java.awt.Dimension(6, 20));
        jl1.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 62, -1));

        jl2.setText("--");
        jl2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl2.setMaximumSize(new java.awt.Dimension(6, 20));
        jl2.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 62, -1));

        jl3.setText("--");
        jl3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl3.setMaximumSize(new java.awt.Dimension(6, 20));
        jl3.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, 62, -1));

        jl4.setText("--");
        jl4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl4.setMaximumSize(new java.awt.Dimension(6, 20));
        jl4.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl4, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 50, 67, -1));

        jl17.setText("--");
        jl17.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl17.setMaximumSize(new java.awt.Dimension(6, 20));
        jl17.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl17, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 70, 80, -1));

        jl5.setText("--");
        jl5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl5.setMaximumSize(new java.awt.Dimension(6, 20));
        jl5.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl5, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 70, 67, -1));

        jl18.setText("--");
        jl18.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl18.setMaximumSize(new java.awt.Dimension(6, 20));
        jl18.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl18, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 90, 80, -1));

        jl6.setText("--");
        jl6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl6.setMaximumSize(new java.awt.Dimension(6, 20));
        jl6.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl6, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 90, 67, -1));

        jl7.setText("--");
        jl7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl7.setMaximumSize(new java.awt.Dimension(6, 20));
        jl7.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl7, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 50, 67, -1));

        jl8.setText("--");
        jl8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl8.setMaximumSize(new java.awt.Dimension(6, 20));
        jl8.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl8, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 70, 67, -1));

        jl13.setText("--");
        jl13.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl13.setMaximumSize(new java.awt.Dimension(6, 20));
        jl13.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl13, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 50, 68, -1));

        jl14.setText("--");
        jl14.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl14.setMaximumSize(new java.awt.Dimension(6, 20));
        jl14.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl14, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 70, 68, -1));

        jl15.setText("--");
        jl15.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl15.setMaximumSize(new java.awt.Dimension(6, 20));
        jl15.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl15, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 90, 68, -1));

        jl16.setText("--");
        jl16.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl16.setMaximumSize(new java.awt.Dimension(6, 20));
        jl16.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl16, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 80, -1));

        jl9.setText("--");
        jl9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl9.setMaximumSize(new java.awt.Dimension(6, 20));
        jl9.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl9, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 90, 67, -1));

        jl10.setText("--");
        jl10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl10.setMaximumSize(new java.awt.Dimension(6, 20));
        jl10.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl10, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 50, 67, -1));

        jl11.setText("--");
        jl11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl11.setMaximumSize(new java.awt.Dimension(6, 20));
        jl11.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl11, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 70, 67, -1));

        jl12.setText("--");
        jl12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl12.setMaximumSize(new java.awt.Dimension(6, 20));
        jl12.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl12, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 90, 67, -1));

        jButton3.setBackground(new java.awt.Color(255, 153, 0));
        jButton3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton3.setText("ACCIÓN");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 140, 140, 40));

        jLabel1.setText("No. de fallos:");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, -1, -1));

        LIMPIAR.setBackground(new java.awt.Color(255, 255, 51));
        LIMPIAR.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        LIMPIAR.setText("LIMPIAR");
        LIMPIAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LIMPIARActionPerformed(evt);
            }
        });
        jPanel1.add(LIMPIAR, new org.netbeans.lib.awtextra.AbsoluteConstraints(370, 190, 140, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 570, 310));

        jPanel2.setBackground(new java.awt.Color(255, 153, 0));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setText("FIFO");

        jButton1.setBackground(new java.awt.Color(0, 0, 0));
        jButton1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("REGRESAR ");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 258, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(35, 35, 35))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jButton1))
                .addContainerGap(62, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, -10, 580, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
a1.setEnabled(false);
b1.setEnabled(false);
c1.setEnabled(false);
d1.setEnabled(false);
e1.setEnabled(false);
f1.setEnabled(false);
        runde();      // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void LIMPIARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LIMPIARActionPerformed
fifo f = new fifo();
f.setVisible (true); 
  dispose();         // TODO add your handling code here:
    }//GEN-LAST:event_LIMPIARActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        menu open = new menu();
        open.setVisible (true);
        dispose();// TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(fifo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(fifo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(fifo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(fifo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new fifo().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton LIMPIAR;
    public static javax.swing.JTextField a1;
    public static javax.swing.JTextField b1;
    public static javax.swing.JTextField c1;
    public static javax.swing.JTextField d1;
    public static javax.swing.JTextField e1;
    public static javax.swing.JTextField f1;
    private javax.swing.JLabel falloscont;
    private javax.swing.JButton jButton1;
    public static javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel jl1;
    private javax.swing.JLabel jl10;
    private javax.swing.JLabel jl11;
    private javax.swing.JLabel jl12;
    private javax.swing.JLabel jl13;
    private javax.swing.JLabel jl14;
    private javax.swing.JLabel jl15;
    private javax.swing.JLabel jl16;
    private javax.swing.JLabel jl17;
    private javax.swing.JLabel jl18;
    private javax.swing.JLabel jl2;
    private javax.swing.JLabel jl3;
    private javax.swing.JLabel jl4;
    private javax.swing.JLabel jl5;
    private javax.swing.JLabel jl6;
    private javax.swing.JLabel jl7;
    private javax.swing.JLabel jl8;
    private javax.swing.JLabel jl9;
    // End of variables declaration//GEN-END:variables
}
