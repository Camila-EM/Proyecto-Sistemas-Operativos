/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto2;

import java.util.Stack;

/**
 *
 * @author Usuario
 */
public class segundaoportunidad extends javax.swing.JFrame {

    /**
     * Creates new form fifo
     */
    public segundaoportunidad() {
        initComponents();
        
    }
    
    public  void runde()
{
 String a2,b2,d2,c2,e2,f2,g2,h2,i2,j2;
        a2=a1.getText();
        b2=b1.getText();
        c2=c1.getText();
        d2=d1.getText();
        e2=e1.getText();
        f2=f1.getText();
        
        String array1[]={a2,b2,c2,d2,e2,f2};
        int fallos=6,r4=0,r5=0,r6=0,r7=0,r8=0,r9=0,r10=0,r11=0,r12=0,r13=0,r14=0,r15=0,r16=0,r17=0,r18=0;
        
        //primero
        jl1.setText(array1[0]);
        
        //segundo
         if(jl1.getText().equals(array1[1])){
            jl4.setText(array1[0]);
            r4++;
            ref4.setText(r4+"");
            fallos --;}
        else {
            jl4.setText(array1[0]);
            jl5.setText(array1[1]);
        };
        
        //tercero
        if(jl4.getText().equals(array1[2])){
            fallos --;
            r7=r4;
            r7++;
            ref7.setText(r7+"");
            jl7.setText(array1[0]);
            jl8.setText(jl5.getText());
        }
        else {//sigue
            jl7.setText(array1[0]);
            if (jl5.getText().equals(array1[2])){
                fallos --;
                r8++;
                r7=r4++;
                ref8.setText(r8+"");
                ref7.setText(r7+"");
                jl8.setText(array1[1]);
                
        }
            else {
                if(jl5.getText().equals("--")){
                   jl7.setText(jl4.getText());
                   jl8.setText(array1[2]);
                   r7=r4;
                   ref7.setText(r7+"");
                }
                else {jl9.setText(array1[2]);
                    r7=r4;
                    r8=r5;
                      ref7.setText(r7+"");
                      jl7.setText(jl4.getText());
                      jl8.setText(array1[1]);
                      ref8.setText(r8+"");
                      ref7.setText(r7+"");
                };
                      
            };
        };
        
  
        //cuarto
        switch (fallos){
            case 6: 
                if(jl7.getText().equals(array1[3])){
                    fallos--;
                     r10=r7;
                     r10++;
                    ref10.setText(r10+"");
                    ref11.setText(ref8.getText());
                    ref12.setText(ref9.getText());
                    
                    jl10.setText(array1[3]);
                    jl11.setText(jl8.getText());
                    jl12.setText(jl9.getText());
                }
                else{
                    if(jl8.getText().equals(array1[3])){   
                       fallos--;
                         r11=r8;
                         r11++;
                        ref10.setText(ref10.getText());
                        ref11.setText(r11+"");
                        ref12.setText(ref9.getText());
                        
                       jl10.setText(jl7.getText());
                       jl11.setText(array1[3]);
                       jl12.setText(jl9.getText());
                }
                    else{
                        if(jl9.getText().equals(array1[3])){   
                        fallos--;
                        
                        r12=r9;
                        r12++;
                        ref10.setText(ref10.getText());
                        ref11.setText(ref11.getText());
                        ref12.setText(r12+"");
                        
                        jl10.setText(jl7.getText());
                        jl11.setText(jl8.getText());
                        jl12.setText(array1[3]);
                }
                        else {
                            ref10.setText(ref7.getText());
                            ref11.setText(ref8.getText());
                            ref12.setText(ref9.getText());
                        
                            jl10.setText(array1[3]);
                             jl11.setText(jl8.getText());
                             jl12.setText(jl9.getText());
                        };
                               };
                };
                
                break;
                
            case 5:
                if (jl7.getText().equals(array1[3])){
                    fallos--;
                     r10=r7;
                     r10++;
                    ref10.setText(r10+"");
                    ref11.setText(ref8.getText());
                    ref12.setText(ref9.getText());
                    
                    jl10.setText(array1[3]);
                    jl11.setText(jl8.getText());
                    jl12.setText(jl9.getText());
                }
                else {
                    if (jl8.getText().equals(array1[3])){   
                       fallos--;
                         r11=r8;
                         r11++;
                        ref10.setText(ref7.getText());
                        ref11.setText(r11+"");
                        ref12.setText(ref9.getText());
                        
                       jl10.setText(jl7.getText());
                       jl11.setText(array1[3]);
                       jl12.setText(jl9.getText());}
                    
                    else{
                         ref10.setText(ref7.getText());
                         ref11.setText(ref8.getText());
                         ref12.setText(ref9.getText());
                        
                         jl10.setText(jl7.getText());
                         jl11.setText(jl8.getText());
                         jl12.setText(array1[3]);
                    };
                };
                
                break;
                
            case 4:
                if (jl7.getText().equals(array1[3])){
                    fallos--;
                    r10=r7;
                     r10++;
                    ref10.setText(r10+"");
                    ref11.setText(ref8.getText());
                    ref12.setText(ref9.getText());
                    
                    jl10.setText(array1[3]);
                    jl11.setText(jl8.getText());
                    jl12.setText(jl9.getText());
                    }
                       
                else {
                    if(jl8.getText().equals(array1[3])){   
                       fallos--;
                       r11=r8;
                       r11++;
                       ref10.setText(ref7.getText());
                       ref11.setText(r11+"");
                       ref12.setText(ref9.getText());
                        
                       jl10.setText(jl7.getText());
                       jl11.setText(array1[3]);
                       jl12.setText(jl9.getText());} 
                        else{
                        ref10.setText(ref7.getText());
                        ref11.setText(ref8.getText());
                        ref12.setText(ref9.getText());
                    
                        jl10.setText(jl7.getText());
                        jl11.setText(array1[3]);
                        jl12.setText(jl9.getText());}
                    };  
        }
        
        
        //quinto 
           switch (fallos){
            case 5: 
                if(jl10.getText().equals(array1[4])){
                    fallos--;
                    jl13.setText(array1[4]);
                    jl14.setText(jl11.getText());
                    jl15.setText(jl12.getText());
                    
                    if(ref10.equals("0")){
                    r13=0;
                    }else{r13=1;};
                    //r13=r10;
                     r13++;
                    ref13.setText(r13+"");
                    ref14.setText(ref11.getText());
                    ref15.setText(ref12.getText());
                }
                else{
                    if(jl11.getText().equals(array1[4])){   
                       fallos--;
                       jl13.setText(jl10.getText());
                       jl14.setText(array1[4]);
                       jl15.setText(jl12.getText());
                       
                       r14=r11;
                       r14++;
                       ref13.setText(ref10.getText());
                       ref14.setText(r14+"");
                       ref15.setText(ref12.getText());
                }
                    else{
                        if(jl12.getText().equals(array1[4])){   
                        fallos--;
                        jl13.setText(jl10.getText());
                        jl14.setText(jl11.getText());
                        jl15.setText(array1[4]);
                        
                       r15=r12;
                       r15++;
                       ref13.setText(ref10.getText());
                       ref14.setText(ref11.getText());
                       ref15.setText(r15+"");
                }
                        else {
                            if(ref10.getText().equals("0")){
                             jl13.setText(array1[4]);
                             jl14.setText(jl11.getText());
                             jl15.setText(jl12.getText());
                             
                           // ref13.setText(ref10.getText());
                            ref14.setText(ref11.getText());
                            ref15.setText(ref12.getText());
                            }
                            else {
                            
                             switch(ref10.getText()){
                            case "0": r13=0;
                            case "1": r13=1;
                            };
                            r13--;
                                if(ref11.getText().equals("0")){
                                 jl13.setText(jl10.getText());
                                 jl14.setText(array1[4]);
                                 jl15.setText(jl12.getText());
                                 
                                 ref13.setText(r13+"");
                                 //ref14.setText(ref11.getText());
                                 ref15.setText(ref12.getText());
                                }
                                else {
                                r14=r11;
                                r14--;
                                
                            };
                        };
                    };
                    }}
                
                break;
                
            case 4:
                if (jl10.getText().equals(array1[4])){
                    fallos--;
                    
                    switch(ref10.getText()){
                    case "0": r13=0;
                    case "1": r13=1;
                    case "2": r13=2;
                    };
                    
                    r13++;
                    ref13.setText(r13+"");
                    ref14.setText(ref11.getText());
                    ref15.setText(ref12.getText());
                    
                    jl13.setText(array1[4]);
                    jl14.setText(jl11.getText());
                    jl15.setText(jl12.getText());
                }
                else {
                    if (jl11.getText().equals(array1[4])){
                    fallos--;
                    
                    /* switch(ref11.getText()){
                    case "0": r14=0;
                    case "1": r14=1;
                    case "2": r14=2;
                    };*/
                    r14=r11;
                    
                    r14++;
                    ref13.setText(ref10.getText());
                    ref14.setText(r14+"");
                    ref15.setText(ref12.getText());
                    
                    jl13.setText(jl10.getText());
                    jl14.setText(array1[4]);
                    jl15.setText(jl12.getText());
                    }
                    else {
                    jl13.setText(jl10.getText());
                    jl14.setText(jl11.getText());
                    jl15.setText(array1[4]);
                    
                    ref13.setText(ref10.getText());
                    ref14.setText(ref11.getText());
                    ref15.setText(ref12.getText());
                    };
                };
                
                break;
                
            case 3: 
                if (jl10.getText().equals(array1[4])){
                    fallos--;
                    
                    switch(ref10.getText()){
                    case "0": r13=0;
                    case "1": r13=1;
                    case "2": r13=2;
                    case "3": r13=3;
                    };
                    
                    r13++;
                    ref13.setText(r13+"");
                    ref14.setText(ref11.getText());
                    ref15.setText(ref12.getText());
                    
                    jl13.setText(array1[4]);
                    jl14.setText(jl11.getText());
                    jl15.setText(jl12.getText());
                }
                else {
                    
                    ref13.setText(ref10.getText());
                    ref14.setText(ref11.getText());
                    ref15.setText(ref12.getText());
                    
                    jl13.setText(jl10.getText());
                    jl14.setText(array1[4]);
                    jl15.setText(jl12.getText());
                    }; 
                break; 
                
            default: 
                if(jl10.getText().equals(array1[4])){
                    fallos--;
                    jl13.setText(array1[4]);
                    jl14.setText(jl1.getText());
                    jl15.setText(jl2.getText());
                    r13++;
                    ref13.setText(r13+"");
                    
                }
                else{
                    if(jl11.getText().equals(array1[4])){   
                       fallos--;
                       jl13.setText(jl10.getText());
                       jl14.setText(array1[4]);
                       jl15.setText(jl12.getText());
                       r14++;
                       ref14.setText(r14+"");
                }
                    else{
                        if(jl2.getText().equals(array1[4])){   
                        fallos--;
                        jl13.setText(jl10.getText());
                        jl14.setText(jl11.getText());
                        jl15.setText(array1[4]);
                        r15++;
                        ref15.setText(r15+"");
                }
                        else {jl13.setText(jl10.getText());
                             jl14.setText(array1[4]);
                             jl15.setText(jl12.getText());
                        };
                               };
                };
        }
           
        //seis
        
             switch (fallos){
             case 6: 
                if(jl13.getText().equals(array1[5])){
                    fallos--;
                    jl16.setText(array1[5]);
                    jl17.setText(jl14.getText());
                    jl18.setText(jl15.getText());
                     r16++;
                    ref16.setText(r16+"");
                    ref17.setText(ref14.getText());
                    ref18.setText(ref15.getText());
                }
                else{
                    if(jl14.getText().equals(array1[5])){   
                       fallos--;
                       jl16.setText(jl13.getText());
                       jl17.setText(array1[5]);
                       jl18.setText(jl15.getText());
                       
                       r17=r14;
                       r17++;
                       ref16.setText(ref13.getText());
                       ref17.setText(r17+"");
                       ref18.setText(ref15.getText());
                }
                    else{
                        if(jl15.getText().equals(array1[5])){   
                        fallos--;
                        jl16.setText(jl13.getText());
                        jl17.setText(jl14.getText());
                        jl18.setText(array1[5]);
                        
                       r18=r15;
                       r18++;
                       ref16.setText(ref13.getText());
                       ref17.setText(ref14.getText());
                       ref18.setText(r18+"");
                }
                        else {
                            
                             jl16.setText(jl13.getText());
                             jl17.setText(jl14.getText());
                             jl18.setText(array1[5]);
                        
                    };
                    }}
                break;
            case 5: 
               if(jl13.getText().equals(array1[5])){
                    fallos--;
                    jl16.setText(array1[5]);
                    jl17.setText(jl14.getText());
                    jl18.setText(jl15.getText());
                     r16++;
                    ref16.setText(r16+"");
                    ref17.setText(ref14.getText());
                    ref18.setText(ref15.getText());
                }
                else{
                    if(jl14.getText().equals(array1[5])){   
                       fallos--;
                       jl16.setText(jl13.getText());
                       jl17.setText(array1[5]);
                       jl18.setText(jl15.getText());
                       
                       r17=r14;
                       r17++;
                       ref16.setText(ref13.getText());
                       ref17.setText(r17+"");
                       ref18.setText(ref15.getText());
                }
                    else{
                        if(jl15.getText().equals(array1[5])){   
                        fallos--;
                        jl16.setText(jl13.getText());
                        jl17.setText(jl14.getText());
                        jl18.setText(array1[5]);
                        
                       r18=r15;
                       r18++;
                       ref16.setText(ref13.getText());
                       ref17.setText(ref14.getText());
                       ref18.setText(r18+"");
                }
                        else {
                            if(ref14.getText().equals(array1[4])){
                                
                             jl16.setText(jl13.getText());
                             jl17.setText(jl14.getText());
                             jl18.setText(array1[5]);}
                           
                        
                    };
                    }}
                
                break;
                
            case 4:
                 if(jl13.getText().equals(array1[5])){
                    fallos--;
                    jl16.setText(array1[5]);
                    jl17.setText(jl14.getText());
                    jl18.setText(jl15.getText());
                    
                }
                else{
                    if(jl14.getText().equals(array1[5])){   
                       fallos--;
                       jl16.setText(jl13.getText());
                       jl17.setText(array1[5]);
                       jl18.setText(jl15.getText());
                }
                    else{
                        if(jl15.getText().equals(array1[5])){   
                        fallos--;
                        jl15.setText(jl13.getText());
                        jl17.setText(jl14.getText());
                        jl18.setText(array1[5]);
                }
                        else {jl16.setText(array1[5]);
                             jl17.setText(jl14.getText());
                             jl18.setText(jl15.getText());
                        };
                               };
                };
                
                break;
                
            case 3:
                if (jl13.getText().equals(array1[5])){
                    fallos--;
                    jl16.setText(array1[4]);
                    jl17.setText(jl14.getText());
                    jl18.setText(jl15.getText());
                }
                else {
                      if(jl14.getText().equals(array1[5])){   
                       fallos--;
                       jl16.setText(jl13.getText());
                       jl17.setText(array1[5]);
                       jl18.setText(jl15.getText());
                      }else {
                        jl16.setText(jl13.getText());
                        jl17.setText(jl14.getText());
                        jl18.setText(array1[5]);
                      } 
                }; 
                break; 
                
            case 2: 
                if(jl13.getText().equals(array1[5])){
                    fallos--;
                    jl16.setText(array1[5]);
                    jl17.setText(jl14.getText());
                    jl18.setText(jl15.getText());
                }
                else{
                       jl16.setText(jl13.getText());
                       jl17.setText(array1[5]);
                       jl18.setText(jl15.getText());
                       
                    }}
                //fin//
        falloscont.setText(fallos+"");
      
}
    
    
  

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        falloscont = new javax.swing.JLabel();
        c1 = new javax.swing.JTextField();
        d1 = new javax.swing.JTextField();
        e1 = new javax.swing.JTextField();
        f1 = new javax.swing.JTextField();
        a1 = new javax.swing.JTextField();
        b1 = new javax.swing.JTextField();
        jl1 = new javax.swing.JLabel();
        jl2 = new javax.swing.JLabel();
        jl3 = new javax.swing.JLabel();
        jl4 = new javax.swing.JLabel();
        jl17 = new javax.swing.JLabel();
        jl5 = new javax.swing.JLabel();
        jl18 = new javax.swing.JLabel();
        jl6 = new javax.swing.JLabel();
        jl7 = new javax.swing.JLabel();
        jl8 = new javax.swing.JLabel();
        jl13 = new javax.swing.JLabel();
        jl14 = new javax.swing.JLabel();
        jl15 = new javax.swing.JLabel();
        jl16 = new javax.swing.JLabel();
        jl9 = new javax.swing.JLabel();
        jl10 = new javax.swing.JLabel();
        jl11 = new javax.swing.JLabel();
        jl12 = new javax.swing.JLabel();
        ref9 = new javax.swing.JLabel();
        ref4 = new javax.swing.JLabel();
        ref5 = new javax.swing.JLabel();
        ref7 = new javax.swing.JLabel();
        ref8 = new javax.swing.JLabel();
        ref12 = new javax.swing.JLabel();
        ref10 = new javax.swing.JLabel();
        ref11 = new javax.swing.JLabel();
        ref15 = new javax.swing.JLabel();
        ref13 = new javax.swing.JLabel();
        ref14 = new javax.swing.JLabel();
        ref18 = new javax.swing.JLabel();
        ref16 = new javax.swing.JLabel();
        ref17 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        LIMPIAR = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(204, 0, 102));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        falloscont.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        falloscont.setForeground(new java.awt.Color(255, 255, 255));
        falloscont.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        falloscont.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(falloscont, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 190, 50, 50));

        c1.setText(" ");
        c1.setMaximumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(c1, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 30, 67, -1));

        d1.setText(" ");
        d1.setMaximumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(d1, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 30, 67, -1));

        e1.setText(" ");
        e1.setMaximumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(e1, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 30, 68, -1));

        f1.setText(" ");
        f1.setMaximumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(f1, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 30, 78, -1));

        a1.setText(" ");
        a1.setMaximumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(a1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 62, -1));

        b1.setText(" ");
        b1.setMaximumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(b1, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 30, 67, -1));

        jl1.setForeground(new java.awt.Color(255, 255, 255));
        jl1.setText("--");
        jl1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl1.setMaximumSize(new java.awt.Dimension(6, 20));
        jl1.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 70, 62, -1));

        jl2.setForeground(new java.awt.Color(255, 255, 255));
        jl2.setText("--");
        jl2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl2.setMaximumSize(new java.awt.Dimension(6, 20));
        jl2.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 62, -1));

        jl3.setForeground(new java.awt.Color(255, 255, 255));
        jl3.setText("--");
        jl3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl3.setMaximumSize(new java.awt.Dimension(6, 20));
        jl3.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 62, -1));

        jl4.setForeground(new java.awt.Color(255, 255, 255));
        jl4.setText("--");
        jl4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl4.setMaximumSize(new java.awt.Dimension(6, 20));
        jl4.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl4, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 70, 67, -1));

        jl17.setForeground(new java.awt.Color(255, 255, 255));
        jl17.setText("--");
        jl17.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl17.setMaximumSize(new java.awt.Dimension(6, 20));
        jl17.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl17, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 90, 80, -1));

        jl5.setForeground(new java.awt.Color(255, 255, 255));
        jl5.setText("--");
        jl5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl5.setMaximumSize(new java.awt.Dimension(6, 20));
        jl5.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl5, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 90, 67, -1));

        jl18.setForeground(new java.awt.Color(255, 255, 255));
        jl18.setText("--");
        jl18.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl18.setMaximumSize(new java.awt.Dimension(6, 20));
        jl18.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl18, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 110, 80, -1));

        jl6.setForeground(new java.awt.Color(255, 255, 255));
        jl6.setText("--");
        jl6.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl6.setMaximumSize(new java.awt.Dimension(6, 20));
        jl6.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl6, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 110, 67, -1));

        jl7.setForeground(new java.awt.Color(255, 255, 255));
        jl7.setText("--");
        jl7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl7.setMaximumSize(new java.awt.Dimension(6, 20));
        jl7.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl7, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 70, 67, -1));

        jl8.setForeground(new java.awt.Color(255, 255, 255));
        jl8.setText("--");
        jl8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl8.setMaximumSize(new java.awt.Dimension(6, 20));
        jl8.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl8, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 90, 67, -1));

        jl13.setForeground(new java.awt.Color(255, 255, 255));
        jl13.setText("--");
        jl13.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl13.setMaximumSize(new java.awt.Dimension(6, 20));
        jl13.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl13, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 70, 68, -1));

        jl14.setForeground(new java.awt.Color(255, 255, 255));
        jl14.setText("--");
        jl14.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl14.setMaximumSize(new java.awt.Dimension(6, 20));
        jl14.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl14, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 90, 68, -1));

        jl15.setForeground(new java.awt.Color(255, 255, 255));
        jl15.setText("--");
        jl15.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl15.setMaximumSize(new java.awt.Dimension(6, 20));
        jl15.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl15, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 110, 68, -1));

        jl16.setForeground(new java.awt.Color(255, 255, 255));
        jl16.setText("--");
        jl16.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl16.setMaximumSize(new java.awt.Dimension(6, 20));
        jl16.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl16, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 70, 80, -1));

        jl9.setForeground(new java.awt.Color(255, 255, 255));
        jl9.setText("--");
        jl9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl9.setMaximumSize(new java.awt.Dimension(6, 20));
        jl9.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl9, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 110, 67, -1));

        jl10.setForeground(new java.awt.Color(255, 255, 255));
        jl10.setText("--");
        jl10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl10.setMaximumSize(new java.awt.Dimension(6, 20));
        jl10.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl10, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 70, 67, -1));

        jl11.setForeground(new java.awt.Color(255, 255, 255));
        jl11.setText("--");
        jl11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl11.setMaximumSize(new java.awt.Dimension(6, 20));
        jl11.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl11, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 90, 67, -1));

        jl12.setForeground(new java.awt.Color(255, 255, 255));
        jl12.setText("--");
        jl12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jl12.setMaximumSize(new java.awt.Dimension(6, 20));
        jl12.setMinimumSize(new java.awt.Dimension(6, 20));
        jPanel1.add(jl12, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 110, 67, -1));

        ref9.setText("0");
        ref9.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(ref9, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 110, 20, 10));

        ref4.setText("0");
        ref4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(ref4, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 70, 20, 10));

        ref5.setText("0");
        ref5.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(ref5, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 90, 20, 10));

        ref7.setText("0");
        ref7.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(ref7, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 70, 20, 10));

        ref8.setText("0");
        ref8.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(ref8, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 90, 20, 10));

        ref12.setText("0");
        ref12.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(ref12, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 110, 20, 10));

        ref10.setText("0");
        ref10.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(ref10, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 70, 20, 10));

        ref11.setText("0");
        ref11.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(ref11, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 90, 20, 10));

        ref15.setText("0");
        ref15.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(ref15, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 110, 20, 10));

        ref13.setText("0");
        ref13.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(ref13, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 70, 20, 10));

        ref14.setText("0");
        ref14.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(ref14, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 90, 20, 10));

        ref18.setText("0");
        ref18.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(ref18, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 110, 20, 10));

        ref16.setText("0");
        ref16.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(ref16, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 70, 20, 10));

        ref17.setText("0");
        ref17.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel1.add(ref17, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 90, 20, 10));

        jButton4.setBackground(new java.awt.Color(102, 0, 102));
        jButton4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("ACCIÓN");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 160, 140, 40));

        LIMPIAR.setBackground(new java.awt.Color(153, 0, 51));
        LIMPIAR.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        LIMPIAR.setForeground(new java.awt.Color(255, 255, 255));
        LIMPIAR.setText("LIMPIAR");
        LIMPIAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LIMPIARActionPerformed(evt);
            }
        });
        jPanel1.add(LIMPIAR, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 210, 140, -1));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("No. de fallos:");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 210, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 50, 630, 280));

        jPanel2.setBackground(new java.awt.Color(153, 0, 51));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("SEGUNDA OPORTUNIDAD");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, 260, 30));

        jButton1.setBackground(new java.awt.Color(0, 0, 0));
        jButton1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("REGRESAR ");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 20, -1, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 620, 60));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        a1.setEnabled(false);
        b1.setEnabled(false);
        c1.setEnabled(false);
        d1.setEnabled(false);
        e1.setEnabled(false);
        f1.setEnabled(false);
        runde();      // TODO add your handling code here:
    }//GEN-LAST:event_jButton4ActionPerformed

    private void LIMPIARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LIMPIARActionPerformed
        segundaoportunidad f = new segundaoportunidad();
        f.setVisible (true);
        dispose();         // TODO add your handling code here:
    }//GEN-LAST:event_LIMPIARActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
menu open = new menu();
         open.setVisible (true);
         dispose();// TODO add your handling code here:
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(segundaoportunidad.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(segundaoportunidad.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(segundaoportunidad.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(segundaoportunidad.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new segundaoportunidad().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton LIMPIAR;
    public static javax.swing.JTextField a1;
    public static javax.swing.JTextField b1;
    public static javax.swing.JTextField c1;
    public static javax.swing.JTextField d1;
    public static javax.swing.JTextField e1;
    public static javax.swing.JTextField f1;
    private javax.swing.JLabel falloscont;
    private javax.swing.JButton jButton1;
    public static javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel jl1;
    private javax.swing.JLabel jl10;
    private javax.swing.JLabel jl11;
    private javax.swing.JLabel jl12;
    private javax.swing.JLabel jl13;
    private javax.swing.JLabel jl14;
    private javax.swing.JLabel jl15;
    private javax.swing.JLabel jl16;
    private javax.swing.JLabel jl17;
    private javax.swing.JLabel jl18;
    private javax.swing.JLabel jl2;
    private javax.swing.JLabel jl3;
    private javax.swing.JLabel jl4;
    private javax.swing.JLabel jl5;
    private javax.swing.JLabel jl6;
    private javax.swing.JLabel jl7;
    private javax.swing.JLabel jl8;
    private javax.swing.JLabel jl9;
    private javax.swing.JLabel ref10;
    private javax.swing.JLabel ref11;
    private javax.swing.JLabel ref12;
    private javax.swing.JLabel ref13;
    private javax.swing.JLabel ref14;
    private javax.swing.JLabel ref15;
    private javax.swing.JLabel ref16;
    private javax.swing.JLabel ref17;
    private javax.swing.JLabel ref18;
    private javax.swing.JLabel ref4;
    private javax.swing.JLabel ref5;
    private javax.swing.JLabel ref7;
    private javax.swing.JLabel ref8;
    private javax.swing.JLabel ref9;
    // End of variables declaration//GEN-END:variables
}
